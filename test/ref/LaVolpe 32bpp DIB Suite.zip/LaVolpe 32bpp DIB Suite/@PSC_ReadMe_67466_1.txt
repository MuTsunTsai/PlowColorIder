Title: LaVolpe 32bpp DIB Suite [9 Mar 08]
Description: Additions: TGA read/write support. Enclosed is a suite of classes that allow you to work strictly with 32bpp DIBs, including recognizing transparency/alpha channels in gifs, icons, pngs, &amp; bitmaps. There are a bunch of "nice to have" routines and maybe an eye-opener or two for some of you. The classes are heavily commented. 18Feb08. Added text support &amp; tiling. Fixed flawed logic in TrimImage. 9Mar08: Added TGA read/write, save as JPG, added Paul Caton's revised CDECL thunks for safer zlib usage, updated sample form. Review Change History in the RTF file for important notes &amp; overview of class functions/properties.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=67466&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
